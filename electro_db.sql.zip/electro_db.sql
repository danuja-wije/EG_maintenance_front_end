-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 15, 2022 at 03:18 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `electro_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `efectedcustomer`
--

CREATE TABLE `efectedcustomer` (
  `interrruptionID` int(11) NOT NULL,
  `customerID` char(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `efectedcustomer`
--

INSERT INTO `efectedcustomer` (`interrruptionID`, `customerID`) VALUES
(32, 'C0001'),
(33, 'C0001'),
(34, 'C0001');

-- --------------------------------------------------------

--
-- Table structure for table `interruption`
--

CREATE TABLE `interruption` (
  `id` int(11) NOT NULL,
  `intType` varchar(50) NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` varchar(100) NOT NULL,
  `approval` varchar(10) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `interruptionStart` datetime NOT NULL,
  `interruptionEnd` datetime NOT NULL,
  `handledBy` char(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `interruption`
--

INSERT INTO `interruption` (`id`, `intType`, `title`, `description`, `approval`, `timestamp`, `interruptionStart`, `interruptionEnd`, `handledBy`) VALUES
(32, 'Demand maintain', 'Demand power cut in kandy', 'Demand power cut in kandy', 'Pending', '2022-05-15 01:11:34', '2022-05-20 04:34:00', '2022-05-30 01:39:00', 'EGEN1'),
(33, 'Special Request', 'Vesak Power Cut', 'Vesak Power Cut', 'Pending', '2022-05-15 01:02:43', '2022-05-19 21:35:00', '2022-05-20 21:35:00', 'EGEN1'),
(34, 'Special Request', 'Vesak Power Cut', 'Vesak Power Cut', 'Pending', '2022-05-15 01:09:44', '2022-05-19 21:35:00', '2022-05-20 21:35:00', 'EGEN1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `efectedcustomer`
--
ALTER TABLE `efectedcustomer`
  ADD PRIMARY KEY (`interrruptionID`,`customerID`),
  ADD KEY `fk_customer` (`customerID`);

--
-- Indexes for table `interruption`
--
ALTER TABLE `interruption`
  ADD PRIMARY KEY (`id`),
  ADD KEY `handledBy` (`handledBy`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `interruption`
--
ALTER TABLE `interruption`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `efectedcustomer`
--
ALTER TABLE `efectedcustomer`
  ADD CONSTRAINT `fk_customer` FOREIGN KEY (`customerID`) REFERENCES `elecro_task_db`.`customer` (`customerID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_interruption` FOREIGN KEY (`interrruptionID`) REFERENCES `interruption` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `interruption`
--
ALTER TABLE `interruption`
  ADD CONSTRAINT `interruption_ibfk_1` FOREIGN KEY (`handledBy`) REFERENCES `elecro_task_db`.`employee` (`empID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
